To use the load script in host/support/loadAR6000.sh, copy the following files to $WORKAREA/target/AR6002/hw2.0/bin/.
athwlan.bin.z77
data.patch.hw2_0.bin
eeprom.data
eeprom.bin
