-"PS_ASIC.pst"
  This file contains radio, system, and firwmare configurabilities.
  Details on how the ".pst" format and definitions can be found in the documents folder.

-"RamPatch.txt"
  This file contains firmware fixes for known defects.  Atheros will release patch files as needed.

Both files are required for the system to be operational.

- "ar3kbdaddr.pst"
This file contains the user configurable Bluetooth Address

Linux:

The files have to be copied to "\lib\firmware\" folder.


Windows CE.

The files have to be copied to "platform\<HardWare Name>\Files" folder.

Please refer the corresponding documents for the exacts steps to be followed.
