#!/bin/bash

#keypad test is evtest

evtest /dev/input/keyboard0
